# Bill of Materials

The course requires part identifiers, ratings, datasheets and cost/source. The exact approved design controls the final BOM.

| Item | Identifier / model | Rating / specification | Qty | Datasheet / source | Cost | Status |
|---|---|---|---:|---|---:|---|
| Source PSU | OKER EB-480 | 480 W Max; 230 V/50 Hz label | 1 | - | - | Used |
| Buck-boost converter | ZK-4KX | Input 5–30 V; output 0.5–30 V (module label) | 1 | - | - | Used |
| Fuse | - | 1 A, 250 V | 4 | - | - | Used |
| Fuse holder | - | Panel mount | 4 | - | - | Used |
| Binding post | - | Insulated panel terminal | - | - | - | Used |
| DC socket | - | Marked 12 V, 120 W max | 1 | - | - | Used |
| Standby LED | - | 5 V | 1 | - | - | Used |
| LED strip | - | 12 V, warm white | 1 | - | - | Used |
| PS_ON switch | - | Maintained insulated switch | 1 | Exact rating - | - | Used |
| IEC inlet/outlet | - | Panel type | - | Exact rating - | - | Used |
| Internal wire | Various | Various sizes according to branch | - | Exact gauges - | - | Used |
| Ferrules/crimp/heat shrink | - | - | - | - | - | Used / exact data - |
| Cable strain relief | - | - | - | - | - | Used / exact data - |
| Fasteners/standoffs | - | - | - | - | - | Used / exact data - |
| Enclosure | - | Approx. 34 × 16.5 cm front dimensions | 1 | - | - | Used |
| DMM | UNI-T UT33A+ | DC voltage measurement | 1 | UNI-T documentation | - | Test instrument |

---