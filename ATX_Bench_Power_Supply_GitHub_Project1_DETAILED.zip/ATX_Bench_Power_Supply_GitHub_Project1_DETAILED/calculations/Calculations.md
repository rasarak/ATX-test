# Engineering Calculations

## 18.1 Fixed-rail regulation

Required:

\[
\% \Delta V = \frac{V_{load}-V_{no-load}}{V_{no-load}}\times100\%
\]

Current measured no-load averages:

- +3.3 V: 3.437 V
- +5 V: 5.237 V
- +12 V: 11.927 V

Because loaded values were not supplied:

- +3.3 V regulation = `-`
- +5 V regulation = `-`
- +12 V regulation = `-`

## 18.2 Branch voltage drop

\[
V_{drop}=V_{upstream}-V_{post}
\]

Actual upstream and post measurements are:

`-`

Therefore calculated branch drop is not reported.

## 18.3 Output power

\[
P_{out}=V_{out}I_{out}
\]

At the recorded adjustable output:

- Vout = 22.00 V
- Iout = `-`
- Pout = `-`

## 18.4 Converter loss

\[
P_{loss}=P_{in}-P_{out}
\]

Actual converter input current and measured efficiency:

`-`

Therefore P_loss = `-`.

## 18.5 Current and power limits

The required comparison is:

**source PSU rail limit → combined rail power → fuse → wire → connector → switch → terminal → converter → temperature limit**

Exact source limits, conductor gauges, connector/switch ratings and measured input current are:

`-`

No unsupported current/power limit is claimed.

## 18.6 Thermal

No temperature measurements were supplied, so no thermal loss estimate or temperature acceptance result is calculated.

---