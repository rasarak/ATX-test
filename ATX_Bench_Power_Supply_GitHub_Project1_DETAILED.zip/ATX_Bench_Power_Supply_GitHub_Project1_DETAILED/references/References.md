# References and Learning Resources

### Required/course sources
1. Electronics Circuits Laboratory — **Project 1: ATX Bench Power Supply**, `03_project01(2).pdf`.
2. Intel — **ATX Version 3 Multi Rail Desktop Platform Power Supply Design Guide**, version 2.1a, as specified by the course.
3. Exact source PSU manufacturer documentation for OKER EB-480: `-`.
4. Exact ZK-4KX module documentation used by team: `-`.
5. UNI-T UT33A+ documentation.

### Course-listed learning resources
The course also lists practical examples/resources including:
- DroneBot Workshop
- GreatScott! DIY Lab Bench Power Supply
- Matthew Beckler
- Frugha
- Beginner breakout-board build
- HowToWith GEO
- TheVDM
- Hackaday.io
- PCB Smoke
- Tom Schmidt
- SparkFun multimeter tutorial
- SparkFun voltage/current/resistance/Ohm's law
- All About Circuits fuse introduction
- Keysight bench-power-supply guidance
- Tektronix power-supply probing guidance

These examples are secondary learning resources. The course specifically states that examples involving opening the source PSU, cutting its harness, floating output common, or using a generic dummy load are outside this project's closed-case external-only procedure.

---