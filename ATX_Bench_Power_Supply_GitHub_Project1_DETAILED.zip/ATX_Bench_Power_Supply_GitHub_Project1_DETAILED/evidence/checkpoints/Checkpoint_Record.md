# Project 1 Checkpoint Record

| Checkpoint | Result / revision required | Instructor/TA | Signature | Date/time |
|---|---|---|---|---|
| Source PSU and connector approval | - | - | - | - |
| Design review | - | - | - | - |
| Unpowered safety check | - | - | - | - |
| Authorization to connect AC | - | - | - | - |
| Authorization for approved load tests | - | - | - | - |
| Load/ripple/thermal sign-off | - | - | - | - |
| Final acceptance | - | - | - | - |
