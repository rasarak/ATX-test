# Project 1 Presentation Outline (8–10 min)

## 1. Need, requirements, source PSU and safety
- Explain the ATX-to-bench-supply goal.
- Identify OKER EB-480.
- Explain closed-case and low-voltage-only boundary.
- Explain branch fusing and safe PS_ON control.

## 2. Block diagram / schematic / protection
- Source PSU → fixed rails / protected branches.
- Source PSU → protected adjustable-converter input → adjustable output.
- Show final as-built schematic if available; current repository field is `-`.

## 3. Construction and design tradeoff
- External enclosure.
- Binding posts, fuses, display, DC socket, indicators.
- Explain why accessible branches require their own protection.

## 4. Measured results
| Output | Average |
|---|---:|
| +3.3 V | 3.437 V |
| +5 V | 5.237 V |
| +12 V | 11.927 V |
| Adjustable | 21.997 V |

## 5. Remaining required tests
State clearly that approved-load, voltage-drop, ripple, thermal and repeated-start records are `-` until actual evidence exists.

## 6. Limitations
- Not a laboratory supply with independent current limiting on every output.
- Exact source-rail limits / wire gauges / switch ratings / some approvals remain `-`.
- -12 V implementation requires documented instructor acceptance.

## 7. Safe operation
Show startup/shutdown and DMM verification. Do not use a paperclip PS_ON jumper.

## 8. Team contributions
Explain specific completed work for each member.
